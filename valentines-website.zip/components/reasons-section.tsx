"use client"

import { useEffect, useRef, useState } from "react"
import { Heart } from "lucide-react"

const reasons = [
  "The way your laugh fills an entire room",
  "How you always know exactly what to say",
  "Your kindness to every person you meet",
  "The way you scrunch your nose when you smile",
  "How you make me want to be a better person",
  "Your strength when things get hard",
  "The little notes and messages you leave me",
  "How safe I feel when I'm with you",
  "Your endless curiosity about the world",
  "The way you look at me like I'm enough",
]

export function ReasonsSection() {
  const [visible, setVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true)
      },
      { threshold: 0.15 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section className="px-6 py-24 md:py-32">
      <div
        ref={ref}
        className={`mx-auto max-w-3xl transition-all duration-1000 ease-out ${
          visible ? "translate-y-0 opacity-100" : "translate-y-12 opacity-0"
        }`}
      >
        <div className="mb-12 text-center">
          <p className="mb-4 text-sm font-sans uppercase tracking-[0.3em] text-muted-foreground">
            A few of the
          </p>
          <h2 className="font-serif text-3xl font-bold text-foreground md:text-5xl">
            <span className="text-balance">Reasons I Love You</span>
          </h2>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className="group flex items-start gap-4 rounded-lg border border-border bg-card p-5 transition-all duration-300 hover:border-primary/30 hover:shadow-sm"
              style={{
                transitionDelay: visible ? `${index * 80}ms` : "0ms",
                opacity: visible ? 1 : 0,
                transform: visible ? "translateY(0)" : "translateY(16px)",
              }}
            >
              <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <Heart className="h-4 w-4 fill-primary text-primary transition-transform duration-300 group-hover:scale-110" />
              </div>
              <p className="font-sans text-sm leading-relaxed text-card-foreground md:text-base">
                {reason}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
